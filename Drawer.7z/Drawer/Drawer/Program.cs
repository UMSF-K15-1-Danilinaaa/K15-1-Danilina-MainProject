﻿using System;
using System.Windows.Forms;
using System.Drawing;

namespace Drawer
{
    class MyButtonClass : Form
    {
        int x = 1, c = 0;
        bool z = true, a = false, b = true, y = false;
        Button ChangeButton;
        ColorDialog ColorDialog2;
        Pen Pen1;

        // Метод-конструктор
        public MyButtonClass()
        {
            Pen1 = new Pen(Color.Black, x);

            //Параметры формы

            this.Width = 800;
            this.Height = 800;
            this.Left = 600;
            this.Top = -50;

            this.Text = "Drawer";



            //Работа с меню
            MainMenu mainMenu1 = new MainMenu();

            MenuItem menuItem1 = new MenuItem("Файл");
            menuItem1.MenuItems.Add("Выход",
            new EventHandler(ExitSelect));
            mainMenu1.MenuItems.Add(menuItem1);
            this.Menu = mainMenu1;

            MenuItem menuItem2 = new MenuItem("Параметры");
            menuItem2.MenuItems.Add("Выбрать цвет кисти",
                new EventHandler(ColorSelect));
            menuItem2.MenuItems.Add("Очистка полотна",
                new EventHandler(Clear));
            mainMenu1.MenuItems.Add(menuItem2);
            menuItem2.MenuItems.Add("Выбрать цвет полотна",
                new EventHandler(BackGroundColorSelect));
            menuItem2.MenuItems.Add("Смена толщины линий и параметров фигур",
                new EventHandler(SizeSelect));

            MenuItem menuItem3 = new MenuItem("О программе");
            menuItem3.MenuItems.Add("О программе",
                new EventHandler(AboutP));
            mainMenu1.MenuItems.Add(menuItem3);



            //Обработчик событий мыши 
            this.MouseDown += new MouseEventHandler(TheMouseIsDown);
            ChangeButton = new Button();
            ChangeButton.Text = "Очистка";
            ChangeButton.Width = 100;
            ChangeButton.Height = 30;
            ChangeButton.Top = 1;
            ChangeButton.Left = 1;
            ChangeButton.Click += new System.EventHandler(Clear);

            this.MouseMove += new MouseEventHandler(TheMouseMoved);
            this.MouseUp += new MouseEventHandler(TheMouseIsUp);


            ColorDialog2 = new ColorDialog();
        }
        
        // Основной метод
        static void Main()
        {           
            Application.Run(new MyButtonClass());            
        }
        public void TheMouseIsDown(Object sender, MouseEventArgs e)
        {
            //Реакция на нажатие левой кнопки
            if (e.Button == MouseButtons.Left)
            {
                c = c + 1;
                if (c == 3)
                    c = 1;
            }
            //Реакция на нажатие правой кнопки
            if (e.Button == MouseButtons.Right)
            {
            }
        }
        void TheMouseIsUp(Object sender, MouseEventArgs e)
        {
            c = c + 1;
        }
        //Рисовалка
        public void TheMouseMoved(Object sender, MouseEventArgs e)
        {
            System.Drawing.Graphics g = this.CreateGraphics();
            if (b == true)
            {
                b = false;
                g.Clear(Color.White);
            }
            if (z == true)
            {

                z = false;
            }
            //Смена цветов

            if (c == 1)
            {
                g.DrawLine(Pen1, e.X, e.Y, 400, 400);
            }
            g.Dispose();

        }
        public void ChangeColor(Object sender, MouseEventArgs e)
        {
            this.MouseMove += new MouseEventHandler(TheMouseMoved);
        }
        public void Clear(Object sender, EventArgs e)
        {
            System.Drawing.Graphics g = this.CreateGraphics();
            if (y == true)
                g.Clear(ColorDialog2.Color);
            else if (y == false)
                g.Clear(Color.White);
        }

        // Обработчик события, срабатывающий при выборе в меню цвета
        void ColorSelect(object sender, System.EventArgs e)
        {
            ColorDialog colorDialog1 = new ColorDialog();
            colorDialog1.ShowDialog();
            Pen1.Color = colorDialog1.Color;
            this.MouseMove += new MouseEventHandler(TheMouseMoved);
        }

        // Обработчик события, срабатывающий при выборе в меню пункта "exit"
        void ExitSelect(object sender, System.EventArgs e)
        {
            if (
            MessageBox.Show("Вы уверены, что хотите закончить работу?",
            "Выход", MessageBoxButtons.YesNo)
            == DialogResult.Yes
           )
            {
                this.Dispose();
            }
        }
        void SizeSelect(Object sender, System.EventArgs e)
        {
        }
        //Смена цветов фона
        void BackGroundColorSelect(Object sender, System.EventArgs e)
        {
            y = true;
            ColorDialog2.ShowDialog();
            System.Drawing.Graphics g = this.CreateGraphics();
            g.Clear(ColorDialog2.Color);
        }
        void AboutP(Object sender, System.EventArgs e)
        {
            About about = new About();
            about.AboutStart();
            about.ShowDialog();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // MyButtonClass
            // 
            this.ClientSize = new System.Drawing.Size(292, 273);
            this.Name = "MyButtonClass";
            this.Load += new System.EventHandler(this.MyButtonClass_Load);
            this.ResumeLayout(false);

        }

        private void MyButtonClass_Load(object sender, EventArgs e)
        {

        }
        
    }
}