﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Drawer
{
    public partial class MyButtonClass : Form
    {
        int /*x = 1, c = 1,*/ height, width/*, b = 0*/;
        public bool z = true, a = false, y = false, t = false;
        Button ChangeButton;
        Select select;
        public Pen Pen1;
        public ColorDialog colorDialog1, ColorDialog2;

        Graphics g;
        List<twoPoints> points = new List<twoPoints>();
        Point point1, point2;
        bool paint = false;
        // private Image picture;
        //  private Point pictureLocation;
        OpenFileDialog opendialog;
        SaveFileDialog savedialog;
        Bitmap bmp;


        // Метод-конструктор
        public MyButtonClass()
        {
            InitializeComponent();
            Pen1 = new Pen(Color.Black, 20);

            //Работа с меню
            MainMenu mainMenu1 = new MainMenu();

            MenuItem menuItem1 = new MenuItem("Файл");
            menuItem1.MenuItems.Add("Открыть файл",

                new EventHandler(Open));
            menuItem1.MenuItems.Add("Выход",
                new EventHandler(ExitSelect));

            mainMenu1.MenuItems.Add(menuItem1);
            this.Menu = mainMenu1;

            MenuItem menuItem2 = new MenuItem("Параметры");
            menuItem2.MenuItems.Add("Смена толщины линий и параметров фигур",
                new EventHandler(SizeSelect));
            mainMenu1.MenuItems.Add(menuItem2);

            MenuItem menuItem3 = new MenuItem("О программе");
            menuItem3.MenuItems.Add("О программе",
                new EventHandler(AboutP));
            mainMenu1.MenuItems.Add(menuItem3);



            //Обработчик событий мыши 








        }
        // Основной метод
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MyButtonClass());
        }
        public void Clear(Object sender, EventArgs e)
        {
            System.Drawing.Graphics g = this.CreateGraphics();
            if (y == true)
            {
            }

            else if (y == false)
                g.Clear(Color.White);
        }





        public void ColorSelect(object sender, System.EventArgs e)
        {
            ColorDialog colorDialog1 = new ColorDialog();
            colorDialog1.ShowDialog();
            Pen1.Color = colorDialog1.Color;
            a = true;

        }
        public void BackColorSelect(Object sender, EventArgs e)
        {
            ColorDialog2 = new ColorDialog();
            ColorDialog2.ShowDialog();
            y = true;
            System.Drawing.Graphics g = CreateGraphics();
        }





        // Обработчик события, срабатывающий при выборе в меню пункта "exit"
        void ExitSelect(object sender, System.EventArgs e)
        {
            if (MessageBox.Show("Вы хотите выйти?",
                                "Выход",
                                MessageBoxButtons.YesNo,
                                MessageBoxIcon.Question)
            == DialogResult.Yes)
            {
                this.Dispose();
            }
        }
        void SizeSelect(Object sender, System.EventArgs e)
        {
            select = new Select();
            select.SelectProp();
            select.Show();
        }
        //Смена цветов фона
        void BackGroundColorSelect(Object sender, System.EventArgs e)
        {

        }
        void AboutP(Object sender, System.EventArgs e)
        {
            About about = new About();
            about.AboutStart();
            about.ShowDialog();
        }
        private void pictureBox1_MouseDown(Object sender, MouseEventArgs e)
        {
            paint = true;
            point1 = e.Location;
        }
        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (paint)
            {
                point2 = e.Location;
                pictureBox1.Invalidate();
            }
        }
        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            paint = false;
            points.Add(new twoPoints(point1, point2));
        }
        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            foreach (twoPoints tp in points)
            {
                e.Graphics.DrawLine(Pens.Red, tp.p1, tp.p2);
            }
            e.Graphics.DrawLine(Pens.Red, point1, point2);
        }



        private void MyButtonClass_Load(object sender, EventArgs e)
        {

        }

        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {

            base.OnClosing(e);

            DialogResult dialogresult = MessageBox.Show("Вы хотите сохранить изображение?",
                                "Выход",
                                MessageBoxButtons.YesNoCancel,
                                MessageBoxIcon.Question);
            if (dialogresult == DialogResult.Cancel)
                e.Cancel = true;
            else if (dialogresult == DialogResult.No)
                Application.Exit();
            else if (dialogresult == DialogResult.Yes)
                сохранитьКакToolStripMenuItem_Click();
        }
        void Open(Object sender, EventArgs e)
        {
            opendialog = new OpenFileDialog();
            opendialog.Filter = "Файлы рисунков (*.BMP, *.JPG, *.GIF, *.TIF, *.PNG, *.ICO, *.EMF, *.WMF)|*.bmp;*.jpg;*.gif; *.tif; *.png; *.ico; *.emf; *.wmf";
            if (opendialog.ShowDialog() == DialogResult.OK)
            {

                Image image = Image.FromFile(opendialog.FileName);
                width = image.Width;
                height = image.Height;
                pictureBox1.Width = width;
                pictureBox1.Height = height;
                bmp = new Bitmap(Image.FromFile(opendialog.FileName), width, height);
                pictureBox1.Image = bmp;


            }
        }
        private void сохранитьКакToolStripMenuItem_Click()
        {       
            SaveFileDialog savedialog = new SaveFileDialog();
            savedialog.Title = "Сохранить картинку как ...";
            savedialog.OverwritePrompt = true;
            savedialog.CheckPathExists = true;
            savedialog.Filter =
                "Bitmap File(*.bmp)|*.bmp|" +
                "GIF File(*.gif)|*.gif|" +
                "JPEG File(*.jpg)|*.jpg|" +
                "TIF File(*.tif)|*.tif|" +
                "PNG File(*.png)|*.png";
            savedialog.ShowHelp = true;
            // If selected, save
            if (savedialog.ShowDialog() == DialogResult.OK)
            {
                
                    // Get the user-selected file name
                    string fileName = savedialog.FileName;
                    // Get the extension
                    string strFilExtn =
                        fileName.Remove(0, fileName.Length - 3);
                    // Save file
                    switch (strFilExtn)
                    {
                        case "bmp":
                            bmp.Save(fileName, System.Drawing.Imaging.ImageFormat.Bmp);
                            break;
                        case "jpg":                            
                            bmp.Save(fileName, System.Drawing.Imaging.ImageFormat.Jpeg);
                            break;
                        case "gif":
                            bmp.Save(fileName, System.Drawing.Imaging.ImageFormat.Gif);
                            break;
                        case "tif":
                            bmp.Save(fileName, System.Drawing.Imaging.ImageFormat.Tiff);
                            break;
                        case "png":
                            bmp.Save(fileName, System.Drawing.Imaging.ImageFormat.Png);
                            break;
                        default:
                            break;
                    
                }

            }

        }

    }
}

